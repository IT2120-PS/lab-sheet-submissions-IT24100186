#setwd("C:\Users\onlin\OneDrive - Sri Lanka Institute of Information Technology\Y2S2")
#dbinom(40,44,0.92)
#pbinom(35,44,0.92,lower.tail = TRUE)
#1- pbinom(37,44,0.92,lower.tail = TRUE)
#pbinom(37,44,0.92,lower.tail = FALSE)



#1)
setwd("C:/Users/onlin/OneDrive - Sri Lanka Institute of Information Technology/Y2S2")
#i.  Binomial Distribution 

#ii. n=50 , p=0.85 
pbinom(46,50,0.85,lower.tail = FALSE)

#2)

#i. X= the number of customer calls received by the call center in one hour.
#ii. Poisson Distribution 
#iii.
dpois(15,12)
