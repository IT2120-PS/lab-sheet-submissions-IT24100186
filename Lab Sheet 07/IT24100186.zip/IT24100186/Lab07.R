setwd("C:/Users/onlin/OneDrive - Sri Lanka Institute of Information Technology/Y2S2/PS/Lab07")

# Ex1:
# P(10 <= X <= 25) = P(X <= 25) - P(X <= 10)
punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)


# Ex2: 
# P(X <= 2)
pexp(2, rate = 1/3)

# Ex3: 

# i. P(X > 130)
1 - pnorm(130, mean = 100, sd = 15)

# ii. IQ score at 95th percentile
qnorm(0.95, mean = 100, sd = 15)
